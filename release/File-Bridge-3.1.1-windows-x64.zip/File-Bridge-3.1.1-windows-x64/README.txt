File Bridge 3.1.1 — Windows x64 完整运行包

完整解压此文件夹，再双击 Start-File-Bridge.cmd。无需安装 Node.js、npm 或 cloudflared。
程序启动后台网站和公网隧道，地址准备好后在普通默认浏览器中打开。
其他电脑、手机打开同一完整网址即可上传。每个浏览器可保存来源名称，统一列表可按来源筛选。
Open-File-Bridge.cmd 再次打开网页；Stop-File-Bridge.cmd 停止本实例。
关闭浏览器不会停止后台。需要主机开机联网；临时隧道重建后网址会变化。
首次运行生成 var/，其中有访问凭据和接收数据，请勿公开上传该目录。
登录自启可选：File-Bridge-CLI.cmd autostart on；关闭用 autostart off。
本包不启用登录自启，不要求配对、管理员安装或系统中的 Node.js。
只含 Windows x64 运行时。Windows 11 实机验收；其他 Windows 版本未实机验收。
